const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcrypt');

// Middleware to protect pages
function isAuthenticated(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

// Register GET
router.get('/register', (req, res) => {
  res.render('register');
});

// Register POST
router.post('/register', async (req, res) => {
  const { username, email, phone, password, re_password } = req.body;

  if (password !== re_password) {
    return res.send('Passwords do not match');
  }

  const hashedPwd = await bcrypt.hash(password, 10);
  const user = new User({ username, email, phone, password: hashedPwd });

  await user.save();
  res.redirect('/login');
});

// Login GET
router.get('/login', (req, res) => {
  res.render('login');
});

// Login POST
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });

  if (user && await bcrypt.compare(password, user.password)) {
    req.session.userId = user._id;
    res.redirect('/');
  } else {
    res.send('Invalid credentials');
  }
});

// Logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Pages (Protected)
router.get('/', isAuthenticated, (req, res) => res.render('home'));
router.get('/skin_care', isAuthenticated, (req, res) => res.render('skin_care'));
router.get('/cure_kitchen', isAuthenticated, (req, res) => res.render('cure_kitchen'));
router.get('/yoga', isAuthenticated, (req, res) => res.render('yoga'));
router.get('/healthy_eating', isAuthenticated, (req, res) => res.render('healhy_eating'));

// User list page
router.get('/users', isAuthenticated, async (req, res) => {
  const users = await User.find();
  res.render('users', { users });
});

module.exports = router;
